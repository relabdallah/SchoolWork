/*----------------------------------------------------------------------------
LAB EXERCISE - Real-Time Operating System
 ----------------------------------------
	Integrate functions developed in previous modules and run then concurrently
	in the mbed RTOS. The following four threads have to be implemented:
	
 1.	Display the temperature on the PC
 2.	Adjust the frequency of a sound wave using a potentiometer
 3.	Display an incrementing counter on the PC
 4.	Blink an LED
 
	GOOD LUCK!
 *----------------------------------------------------------------------------*/

#include "mbed.h"
#include "rtos.h"
#include "DS1631.h"
#include "pindef.h"

/*
Define the mutex
Define the PC display and the temperature sensor
Define other inputs and outputs
*/

//Write your code here


//Display temperature on the PC
void temp_thread(void const *args){
	
	//write your code here
	
}

//Adjust the fequency of the sound wave
void adjust_frquency(void const *args){
	
	//write your code here
	
}

//Blink an LED
void led1_thread(void const *args){
	
	//write your code here
	
}

//Display a counter on the PC
void count_thread(void const *args){
	
	//write your code here
	
}

/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/

int main(){
	/*
	Initialise 
	Start all threads
		*/
	
	//write your code here
	
	//Wait for timer interrupt
	  while(1){
		__wfi();
	}

}

// *******************************ARM University Program Copyright (c) ARM Ltd 2014*************************************
